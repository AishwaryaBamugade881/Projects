package com.tka.BookManagement.Services;


import com.tka.BookManagement.Dao.BookDao;
import com.tka.BookManagement.Entity.Book;

public class BookService {
	BookDao bookDao=new BookDao();
	public void insertBook(Book book) {
		bookDao.insertBook(book);
	}
}
