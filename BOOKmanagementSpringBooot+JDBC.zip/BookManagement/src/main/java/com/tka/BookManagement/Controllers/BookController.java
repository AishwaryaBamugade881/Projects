package com.tka.BookManagement.Controllers;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.tka.BookManagement.Entity.Book;
import com.tka.BookManagement.Services.BookService;
@RestController
public class BookController {
	BookService bookService=new BookService();
	
@PostMapping("addbook")	
public void insertBook(@RequestBody
	Book book) {
	bookService.insertBook(book);
}


/*
 * public void updateBook(Book book) {
 * 
 * } public void deleteBook(Book book) {
 * 
 * } public void ShowAllBook() {
 * 
 * }
 */
}
