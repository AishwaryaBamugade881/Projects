package com.tka.BookManagement.Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;


import com.tka.BookManagement.Entity.Book;

public class BookDao {
//all operation of JDBC
	private static final String url = "jdbc:mysql://localhost:3307/200_Advancejava";
	private static final String username = "root";
	private static final String password = "root";
	public static Connection con;
	public static PreparedStatement pstmt;

	public static Connection getDbConnection() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(url, username, password);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return con;
	}
	public  void insertBook(Book book) {
		String sql = "insert into book values(?,?,?,?)";

		try {
			System.out.println(1);
			con=getDbConnection();;
			System.out.println(2);
			pstmt = con.prepareStatement(sql);
			System.out.println(3);
			pstmt.setInt(1,book.getId() );
			pstmt.setString(2, book.getName());
			System.out.println(book.getAuthor());
			pstmt.setString(3, book.getAuthor());
			pstmt.setDouble(4, book.getPrice());
			
			pstmt.executeUpdate();
			
			System.err.println("Data inserted successfully");
		} catch (SQLException e) {
			System.out.println("Exception occured");
			e.printStackTrace();
		}
	}
}
